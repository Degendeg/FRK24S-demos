const WeatherDetails = () => {
  return (
    <div>
      <h3>Hello From {WeatherDetails.displayName || WeatherDetails.name}!</h3>
      <p>
        Duis vel dignissim lorem, id imperdiet arcu. Quisque vel dignissim elit. Donec id massa est. Nunc commodo auctor tellus, eget dictum lectus. Quisque sed commodo nibh. Sed at hendrerit tellus. Vestibulum nec purus dui. Donec a augue leo. Maecenas ornare, ligula non gravida maximus, sapien mauris sagittis metus, id tempor felis quam vel risus. In vitae congue tortor. Etiam porttitor ligula vitae aliquet rhoncus. Etiam congue lectus nec ex porttitor, vel faucibus lorem imperdiet. Quisque imperdiet, sem quis scelerisque accumsan, est massa lobortis est, sit amet bibendum nibh ex eget enim.
      </p>
    </div>
  )
}
export default WeatherDetails